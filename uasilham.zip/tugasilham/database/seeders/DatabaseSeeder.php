<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'nama' => 'Ilham Prabowo',
            'email' => 'ilhamprabowo@gmail.com',
            'alamat' => 'Tebing Tinggi',
            'hp' => '082212123432',
            'pos' => '001100',
            'role' => 1,
            'aktif' => 1,
            'password' => Hash::make('kosong')
        ]);
    }
}
